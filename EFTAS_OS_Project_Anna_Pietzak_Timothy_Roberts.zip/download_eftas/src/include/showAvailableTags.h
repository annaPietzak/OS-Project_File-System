#ifndef CHECKIFTAGISKNOWN_H
#define CHECKIFTAGISKNOWN_H

#include <sys/stat.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>


int show_available_tags();

#endif //CHECKIFTAGISKNOWN_H
