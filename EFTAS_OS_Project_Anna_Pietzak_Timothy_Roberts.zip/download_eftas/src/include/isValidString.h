#ifndef ISVALIDSTRING_H
#define ISVALIDSTRING_H

#include <ctype.h>
#include <stdio.h>

int is_valid_string(const char *str);

#endif //ISVALIDSTRING_H
