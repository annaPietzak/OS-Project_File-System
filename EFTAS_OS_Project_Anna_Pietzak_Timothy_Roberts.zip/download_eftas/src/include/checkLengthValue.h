#ifndef CHECKLENGTHVALUE_H
#define CHECKLENGTHVALUE_H

#include <string.h>
#include <stdio.h>

#define MAX_ATTR_VALUE_SIZE 3072

int check_tag_value(const char * taValue);

#endif //CHECKLENGTHVALUE_H
