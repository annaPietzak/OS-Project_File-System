#ifndef CHECKIFTAGISKNOWN_H
#define CHECKIFTAGISKNOWN_H

#include <sys/stat.h>
#include <stdio.h>
#include <string.h>
#include <stdbool.h>
#include <stdlib.h>

int check_if_tag_is_known(const char * tagName);

#endif //CHECKIFTAGISKNOWN_H
