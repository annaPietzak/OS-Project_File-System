#ifndef CHECKFILEPATH_H
#define CHECKFILEPATH_H

#include <sys/stat.h>
#include <unistd.h>


int check_file_path(const char * filePath);

#endif //CHECKFILEPATH_H
