#ifndef CHECKLENGTHNAME_H
#define CHECKLENGTHNAME_H

#include <string.h>
#include <stdio.h>

#define MAX_ATTR_NAME_SIZE 255

int check_tag_name(const char * tagName);

#endif //CHECKLENGTHNAME_H
